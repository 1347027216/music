from scrapy import cmdline


# cmdline.execute("scrapy crawl wy".split())
cmdline.execute("scrapy crawl qq".split())
